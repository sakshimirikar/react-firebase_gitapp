import React from "react";

const Signin = () => {
  return (
    <div>
      <h1>Signin page</h1>
    </div>
  );
};

export default Signin;
